package com.example.helpmeapp;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "helpme.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "contacts";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_AGE = "number";
    private static final String COLUMN_ADD = "addrress";

    public MyDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_AGE + " TEXT, " +
                COLUMN_ADD + " TEXT ) ";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF exists "+TABLE_NAME);
    }

    public void insertData(String name, String number,String address) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_AGE, number);
        values.put(COLUMN_ADD, address);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }
    public Cursor fetch(SQLiteDatabase db){
        String[] columns= new String[] {COLUMN_ID , COLUMN_NAME,COLUMN_AGE,COLUMN_ADD};
        Cursor cursor=db.query(TABLE_NAME,columns,null,null,null,null,COLUMN_ID,null);
        if(cursor!=null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Boolean registered (SQLiteDatabase db){
        Boolean reg=true;
        Cursor g=fetch(db);
        if(g.getCount()>0)
        {
                reg=true;
        }
        else{
            reg=false;
        }
        return reg;
    }
    public void del(String num){
        getReadableDatabase().delete(TABLE_NAME,"number=?", new String[]{num});

    }

}

