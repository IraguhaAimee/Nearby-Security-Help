package com.example.helpmeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class ontacts extends AppCompatActivity {
    MyDatabaseHelper dbmng;
    RecyclerView recyclerView;
    ArrayList<String> nam,id,numb;
    SQLiteDatabase db;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.tool1,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.contacts:
                Intent intent=new Intent(getApplicationContext(),selectcontacts.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @SuppressLint("Range")
    public void sdisplay(){
        Cursor cursor= dbmng.fetch(db);
        if(cursor.getCount()==0){
            Toast.makeText(this,"no contacts",Toast.LENGTH_SHORT).show();
        }else{
            id.add(String.valueOf(cursor.getInt(cursor.getColumnIndex("id"))));
            numb.add(cursor.getString(cursor.getColumnIndex("number")));
            nam.add(cursor.getString(cursor.getColumnIndex("name"))+"("+cursor.getString(cursor.getColumnIndex("addrress"))+")");

            while(cursor.moveToNext()){
                id.add(String.valueOf(cursor.getInt(cursor.getColumnIndex("id"))));
                numb.add(cursor.getString(cursor.getColumnIndex("number")));
                nam.add(cursor.getString(cursor.getColumnIndex("name"))+"("+cursor.getString(cursor.getColumnIndex("addrress"))+")");


            }
        }
    }
    Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ontacts);
        add=findViewById(R.id.buta);
        dbmng=new MyDatabaseHelper(this);
        db=dbmng.getWritableDatabase();
        nam=new ArrayList<>();
        id=new ArrayList<>();
        numb=new ArrayList<>();
        recyclerView=findViewById(R.id.rview);
        sdisplay();
        precycler mycall=new precycler(this,id,nam,numb);
        recyclerView.setAdapter(mycall);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),selectcontacts.class);
                startActivity(intent);
            }
        });
    }
}