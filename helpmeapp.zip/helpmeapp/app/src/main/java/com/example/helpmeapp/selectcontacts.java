package com.example.helpmeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class selectcontacts extends AppCompatActivity {
    EditText num,nam,addr;
    Button sub,don;
    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectcontacts);
        MyDatabaseHelper dbHelper = new MyDatabaseHelper(this);
        db=dbHelper.getWritableDatabase();
        num=findViewById(R.id.editText1);
        nam=findViewById(R.id.editText);
        addr=findViewById(R.id.editText2);
        sub=findViewById(R.id.button);
        don=findViewById(R.id.button1);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name,number,address;
                name=nam.getText().toString();
                number=num.getText().toString();
                address=addr.getText().toString();
                dbHelper.insertData(name,number,address);
                nam.setText("");
                num.setText("");
                addr.setText("");

            }
        });
        don.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                intent = new Intent(selectcontacts.this,
                        MainActivity.class);
                startActivity(intent);
            }
        });

    }
}