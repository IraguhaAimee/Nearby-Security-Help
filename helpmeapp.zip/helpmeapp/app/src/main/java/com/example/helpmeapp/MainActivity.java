package com.example.helpmeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements shakeme.OnShakeListener{
    
        private SensorManager mSensorManager;
        private Sensor mAccelerometer;
        private shakeme mshakeme;
        private Button safe;
    private static final int REQUEST_LOCATION_PERMISSION = 1;

    private LocationManager locationManager;
    private LocationListener locationListener;
    private static final int PERMISSION_REQUEST_SEND_SMS = 1;
        SQLiteDatabase db;
    MyDatabaseHelper dbHelper;
        TextView sh;
    double latitude;
    double longitude;

    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
        sh=findViewById(R.id.show);
        safe=findViewById(R.id.safeb);
            dbHelper = new MyDatabaseHelper(this);
            db=dbHelper.getWritableDatabase();
            if(!dbHelper.registered(db)){

                Intent intent=new Intent(this,
                        selectcontacts.class);
                startActivity(intent);
            }
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[] { android.Manifest.permission.SEND_SMS }, PERMISSION_REQUEST_SEND_SMS);
            }
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            locationListener = new LocationListener() {

                @Override
                public void onLocationChanged(Location location) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                   // sh.setText("Latitude: " + latitude + ", Longitude: " + longitude);

                    // Do something with the latitude and longitude
                    //Toast.makeText(MainActivity.this, "Latitude: " + latitude + ", Longitude: " + longitude,
                            //Toast.LENGTH_SHORT).show();
                }
                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {}

                @Override
                public void onProviderEnabled(String provider) {}

                @Override
                public void onProviderDisabled(String provider) {}
            };
          //
            mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            mshakeme = new shakeme();
            mshakeme.setOnShakeListener(this);
            safe.setOnClickListener(new View.OnClickListener() {
                @SuppressLint("Range")
                @Override
                public void onClick(View v) {
                    Cursor nums=dbHelper.fetch(db);
                    for (int i=0;i<nums.getCount();i++){
                        if (ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                            SmsManager smsManager = SmsManager.getDefault();
                            smsManager.sendTextMessage(nums.getString(nums.getColumnIndex("number")), null, "I am safe now!!", null, null);
                            Toast.makeText(MainActivity.this, "SMS sent", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
                        }
                        nums.moveToNext();

                    }
                }
            });
        }

        @Override
        protected void onResume() {
            super.onResume();
            mSensorManager.registerListener(mshakeme, mAccelerometer, SensorManager.SENSOR_DELAY_UI);
            super.onResume();
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                        0, 0, locationListener);
                //Location here=new Location(locationListener.);
            } else {
                // Request location permission if not granted
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_LOCATION_PERMISSION);
            }
        }

        @Override
        protected void onPause() {
            mSensorManager.unregisterListener(mshakeme);
            super.onPause();
            locationManager.removeUpdates(locationListener);
        }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case PERMISSION_REQUEST_SEND_SMS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.tool,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.contacts:
                Intent intent=new Intent(getApplicationContext(),ontacts.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

        @SuppressLint("Range")
        @Override
        public void onShake() {
            //sh.setText("I am shaking");
            // Do something when device is shaken
            Cursor nums=dbHelper.fetch(db);
            //sh.setText("I am shaking"+ nums.getCount());
            //sh.setText("I am shaking");

            for (int i=0;i<nums.getCount();i++){
                //sh.setText(nums.getString(nums.getColumnIndex("number")));
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(nums.getString(nums.getColumnIndex("number")), null, "help me please i am here: https://www.google.com/search?q="+latitude+","+longitude, null, null);
                    Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
                }
                nums.moveToNext();

            }
        }

    }
